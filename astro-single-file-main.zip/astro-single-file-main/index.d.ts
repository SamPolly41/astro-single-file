import type { AstroIntegration } from 'astro';
export default function astroSingleFile(): AstroIntegration;
